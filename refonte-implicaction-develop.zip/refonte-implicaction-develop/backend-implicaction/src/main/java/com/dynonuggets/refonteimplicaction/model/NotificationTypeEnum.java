package com.dynonuggets.refonteimplicaction.model;

public enum NotificationTypeEnum {
    USER_REGISTRATION,
    USER_ACTIVATION,
    JOB_ACTIVATION,
    POST_CREATION,
    COMMENT_ADD
}
