package com.dynonuggets.refonteimplicaction.repository;


import com.dynonuggets.refonteimplicaction.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificationRepository extends JpaRepository<Notification, Long> {

}
