package com.dynonuggets.refonteimplicaction.dto;

public enum RelationTypeEnum {
    FRIEND, RECEIVER, SENDER, NONE
}
