package com.dynonuggets.refonteimplicaction.model;

public enum ContractTypeEnum {
    CDI, CDD, ALTERN, INTERIM
}
