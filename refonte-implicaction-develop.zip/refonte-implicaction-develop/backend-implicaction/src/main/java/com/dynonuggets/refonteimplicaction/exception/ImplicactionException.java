package com.dynonuggets.refonteimplicaction.exception;

public class ImplicactionException extends RuntimeException {
    public ImplicactionException(String message) {
        super(message);
    }
}
