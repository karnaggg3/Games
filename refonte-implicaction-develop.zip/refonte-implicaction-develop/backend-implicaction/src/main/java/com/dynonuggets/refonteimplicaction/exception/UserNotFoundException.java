package com.dynonuggets.refonteimplicaction.exception;

public class UserNotFoundException extends ImplicactionException{

    public UserNotFoundException(String message) {
        super(message);
    }
}