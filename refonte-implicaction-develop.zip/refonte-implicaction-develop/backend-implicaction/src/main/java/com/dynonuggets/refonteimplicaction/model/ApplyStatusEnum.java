package com.dynonuggets.refonteimplicaction.model;

public enum ApplyStatusEnum {
    PENDING, SENT, CHASED, INTERVIEW, REJECTED, HIRED
}
