package com.dynonuggets.refonteimplicaction.exception;

public class UnauthorizedException extends ImplicactionException {

    public UnauthorizedException(String message) {
        super(message);
    }
}
