package com.dynonuggets.refonteimplicaction.exception;

public class NotFoundException extends ImplicactionException {

    public NotFoundException(String message) {
        super(message);
    }
}
