import {BrPipe} from './eol.pipe';

describe('EolPipe', () => {
  it('create an instance', () => {
    const pipe = new BrPipe();
    expect(pipe).toBeTruthy();
  });
});
