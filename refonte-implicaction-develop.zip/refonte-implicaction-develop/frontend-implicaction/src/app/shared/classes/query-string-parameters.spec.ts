import {QueryStringParameters} from './query-string-parameters';

describe('QueryStringParameters', () => {
  it('should create an instance', () => {
    expect(new QueryStringParameters()).toBeTruthy();
  });
});
