import {UrlBuilder} from './url-builder';

describe('UrlBuilder', () => {
  it('should create an instance', () => {
    expect(new UrlBuilder()).toBeTruthy();
  });
});
