export class Utils {

  public static isEqual = (o1: any, o2: any): boolean => JSON.stringify(o1) === JSON.stringify(o2);

}
