import {SidebarContentDirective} from './sidebar-content.directive';

describe('SidebarContentDirective', () => {
  it('should create an instance', () => {
    const directive = new SidebarContentDirective();
    expect(directive).toBeTruthy();
  });
});
