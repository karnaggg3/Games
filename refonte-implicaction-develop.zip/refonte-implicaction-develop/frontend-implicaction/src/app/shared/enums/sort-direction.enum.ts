export enum SortDirectionEnum {
  ASC = 'ASC', DESC = 'DESC'
}
