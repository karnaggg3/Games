export interface WorkExperience {
  id?: string;
  startedAt?: string;
  finishedAt?: string;
  description?: string;
  label?: string;
  companyName?: string;
}
