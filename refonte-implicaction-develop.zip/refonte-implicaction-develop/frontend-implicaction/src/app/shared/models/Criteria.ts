export interface Criteria {
  keyword?: string;
}
