export interface Training {
  id?: string;
  label?: string;
  school?: string;
  date?: string;
}
