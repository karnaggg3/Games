export interface Company {
  id?: string;
  description?: string;
  logo?: string;
  name?: string;
  url?: string;
}
