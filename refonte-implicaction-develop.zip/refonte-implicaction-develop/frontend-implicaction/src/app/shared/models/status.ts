export interface Status {
  id?: string;
  label?: string;
  type?: string;
}
