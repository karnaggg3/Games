import {Component} from '@angular/core';

@Component({
  selector: 'app-top-group-skeleton',
  templateUrl: './top-group-skeleton.component.html',
  styleUrls: ['./top-group-skeleton.component.scss']
})
export class TopGroupSkeletonComponent {
}
