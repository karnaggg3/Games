import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-comment-skeleton',
  templateUrl: './comment-skeleton.component.html',
  styleUrls: ['./comment-skeleton.component.scss']
})
export class CommentSkeletonComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
  }

}
