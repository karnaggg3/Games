export interface CommentPayload {
  text: string;
  postId: string;
}
