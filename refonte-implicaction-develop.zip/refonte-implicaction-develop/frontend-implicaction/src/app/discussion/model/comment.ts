export interface Comment {
  id?: string;
  text?: string;
  postId?: number;
  username?: string;
  userId?: string;
  userImageUrl?: string;
  duration?: string;
}
