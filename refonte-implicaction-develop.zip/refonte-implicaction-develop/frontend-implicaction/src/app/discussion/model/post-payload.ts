export interface PostPayload {
  name: string;
  groupId?: string;
  url?: string;
  description?: string;
}
